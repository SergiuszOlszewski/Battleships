import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class battleships extends PApplet {

float scale;
Boolean gameStarted=false;
Boolean lockedBoard=false;
int[] shipsToPlace={4, 3, 3, 2, 2, 2, 1, 1, 1, 1};
int dir=0;

Ship[] playerShips = new Ship[10];
Ship[] computerShips = new Ship[10];
public void setup()
{
  
  scale = 400;
}
Board player = new Board(100, 100, "player");
Board computer = new Board(600, 100, "computer");

int xyTemp;
public void draw()
{
  player.zeroBoardAfterMouse();
  xyTemp = player.mouseToField();
  if (xyTemp!=-1&&player.fields[xyTemp/100][xyTemp%100]==0)
    player.fields[xyTemp/100][xyTemp%100]=-1;

  player.show();
  computer.show();
}

public void mousePressed()
{  
  xyTemp=-1;
  if (!gameStarted)
  {
    xyTemp = player.mouseToField();
    if (xyTemp!=-1&&mouseButton == RIGHT)
      dir++;
    if (xyTemp!=-1&&mouseButton == LEFT)
    {
      int i=0;
      while (i<10&&playerShips[i]!=null)
      {
        i++;
      }
      if (i>=10)
      {
        lockedBoard=true;
        placeCompShips();
        lockedBoard=false;
        gameStarted=true;
        return;
      }
      int x=xyTemp/100;
      int y=xyTemp%100;
      Ship temp = new Ship(); //gdyby metody statyczne działały jak należy...
      if (temp.checkForPlace(x, y, dir%2, shipsToPlace[i], player))
      {
        temp.place(x, y, dir%2, shipsToPlace[i], player);
        playerShips[i] = temp;
      }
      i=0;
      while (i<10&&playerShips[i]!=null)
      {
        i++;
      }
      if (i>=10)
      {
        lockedBoard=true;
        placeCompShips();
        lockedBoard=false;
        gameStarted=true;
        return;
      }
    }
  }
  if (gameStarted)
  {
    xyTemp = computer.mouseToField();
    if (xyTemp!=-1)
    {
      int x=xyTemp/100;
      int y=xyTemp%100;
      if(!computer.shoot(x, y))
        return;  
      lockedBoard=true;
      x=(int)random(0, 10);
      y=(int)random(0, 10);
      while (player.fields[x][y]==2||player.fields[x][y]==3||player.fields[x][y]==-2)
      {
        x=(int)random(0, 10);
        y=(int)random(0, 10);
      }
      println(x+", "+y);
      player.shoot(x, y);
      lockedBoard=false;
      if (checkforGameEnd()=="player")
        background(0, 255, 0);
      if (checkforGameEnd()=="computer")
        background(255, 0, 0);
    }
  }
}

public void placeCompShips()
{
  for (int i=0; i<10; i++)
  {
    Ship temp = new Ship();
    int x=(int)random(0, 10);
    int y=(int)random(0, 10);
    int dir=(int)random(0, 2);
    while (!temp.checkForPlace(x, y, dir%2, shipsToPlace[i], computer))
    {
      x=(int)random(0, 10);
      y=(int)random(0, 10);
      dir=(int)random(0, 2);
    }
    temp.place(x, y, dir%2, shipsToPlace[i], computer);
    computerShips[i] = temp;
    println(x+", " +y+", "+dir%2);
  }
}

public String checkforGameEnd()
{
  int shipsLeft=10;
  for (Ship ship : computerShips)
    if (ship.live==0)
      shipsLeft--;
  if (shipsLeft==0)
    return("player");
  shipsLeft=10;
  for (Ship ship : playerShips)
    if (ship.live==0)
      shipsLeft--;
  if (shipsLeft==0)
    return("computer");
  return("notYet");
}

class Board
{
  int[][]fields = new int[10][10];
  int x;
  int y;
  String owner;
  Board(int _x, int _y, String _owner)
  {
    this.owner=_owner;
    this.x=_x;
    this.y=_y;
    for (int i=0; i<10; i++)
      for (int j=0; j<10; j++)
        fields[i][j]=0;
  }

  public void zeroBoardAfterMouse()
  {
    for (int i=0; i<10; i++)
      for (int j=0; j<10; j++)
        if (fields[i][j]==-1)
          fields[i][j]=0;
  }
  public void show()
  {
    for (int i=0; i<10; i++)
    {
      for (int j=0; j<10; j++)
      {
        if (this.fields[i][j]==0||(this.fields[i][j]==1&&this.owner=="computer"))
          fill(255);
        if (this.fields[i][j]==1&&this.owner=="player")
          fill(0, 0, 255);
        if (this.fields[i][j]==-1)
          fill(200, 200, 200);
        if (this.fields[i][j]==2)
          fill(255, 255, 0);
        if (this.fields[i][j]==-2)
          fill(200, 200, 255);
        if (this.fields[i][j]==3)
          fill(255, 0, 0);
        rect(this.x+i*40, this.y+j*40, 40, 40);
      }
    }
  }

  public int mouseToField()
  {
    if (lockedBoard)
      return -1;
    if (mouseX>=this.x && mouseX<this.x+400 && mouseY>=this.y && mouseY<this.y+400)
      return (100*((mouseX-this.x)/40))+(mouseY-this.y)/40; 
    else
      return -1;
  }

  public Boolean shoot(int _x, int _y)
  {
    if (this.fields[_x][_y]==2)
      return false;
    if (this.fields[_x][_y]==3)
      return false;
    if (this.fields[_x][_y]==0||this.fields[_x][_y]==-1)
    {
      this.fields[_x][_y]=-2;
      return true;
    }
    if (this.fields[_x][_y]==1)
    {
      this.fields[_x][_y]=2;
      if (this.owner=="computer")
      {
        for (Ship ship : computerShips)
        {
          if (ship.checkIfOverXY(_x, _y))
          {
            ship.live--;
            if (ship.live<=0)
              ship.destroy();
          }
        }
      }
      if (this.owner=="player")
      {
        for (Ship ship : playerShips)
        {
          if (ship.checkIfOverXY(_x, _y))
          {
            ship.live--;
            if (ship.live<=0)
              ship.destroy();
          }
        }
      }
      return true;
    }
    return false;
  }
}

class Ship
{
  int x;
  int y;
  int len;
  int dir;
  int live;
  Board owner;
  Ship()
  {
  }
  public void place(int _x, int _y, int _dir, int _len, Board _owner)
  {
    this.x=_x;
    this.y=_y;
    this.len=_len;
    this.dir=_dir;
    this.owner=_owner;
    this.live=_len;
    if (_dir==0)
    {

      for (int i=_x; i<_x+_len; i++)
        _owner.fields[i][_y]=1;
    }
    if (_dir==1)
    {
      for (int i=_y; i<_y+_len; i++)
        _owner.fields[_x][i]=1;
    }
  }

  public Boolean checkForPlace(int _x, int _y, int _dir, int _len, Board _owner)
  {
    if (_dir==0)
    {
      if (_x<0 || _y<0 || _x>10-_len ||_y>10)
        return false;
      for (int i=_x; i<_x+_len; i++)
        if (_owner.fields[i][_y]==1)
          return false;
      if (_x>0)
        if (_owner.fields[_x-1][_y]==1)
          return false;
      if (_x+_len<9)
        if (_owner.fields[_x+_len][_y]==1)
          return false;
      if (_y>0)
        for (int i=_x; i<_x+_len; i++)
          if (_owner.fields[i][_y-1]==1)
            return false;
      if (_y<9)
        for (int i=_x; i<_x+_len; i++)
          if (_owner.fields[i][_y+1]==1)
            return false;
      if (_x>0&&_y>0)
        if (_owner.fields[_x-1][_y-1]==1)
          return false;
      if (_x>0&&_y<9)
        if (_owner.fields[_x-1][_y+1]==1)
          return false;
      if (_x+_len<9&&_y>0)
        if (_owner.fields[_x+_len][_y-1]==1)
          return false;
      if (_x+_len<9&&_y<9)
        if (_owner.fields[_x+_len][_y+1]==1)
          return false;
    }
    if (_dir==1)
    {
      if (_x<0 ||_y<0 ||_x>10 || _y>10-_len)
        return false;
      for (int i=_y; i<_y+_len; i++)
        if (_owner.fields[_x][i]==1)
          return false;
      if (_y>0)
        if (_owner.fields[_x][_y-1]==1)
          return false;
      if (_y+_len<9)
        if (_owner.fields[_x][_y+_len]==1)
          return false;
      if (_x>0)
        for (int i=_y; i<_y+_len; i++)
          if (_owner.fields[_x-1][i]==1)
            return false;
      if (_x<9)
        for (int i=_y; i<_y+_len; i++)
          if (_owner.fields[_x+1][i]==1)
            return false;
      if (_x>0&&_y>0)
        if (_owner.fields[_x-1][_y-1]==1)
          return false;
      if (_x>0&&_y+_len<9)
        if (_owner.fields[_x-1][_y+_len]==1)
          return false;
      if (_x<9&&_y>0)
        if (_owner.fields[_x+1][_y-1]==1)
          return false;
      if (_x<9&&_y+_len<9)
        if (_owner.fields[_x+1][_y+_len]==1)
          return false;
    }
    return true;
  }

  public Boolean checkIfOverXY(int _x, int _y)
  {
    if (this.dir==1)
    {
      for (int i=this.y; i<this.y+this.len; i++)
        if (_y==i&&_x==this.x)
          return true;
    }
    if (this.dir==0)
    {
      for (int i=this.x; i<this.x+this.len; i++)
        if (_x==i&&_y==this.y)
          return true;
    }

    return false;
  }
  public void destroy()
  {
    if (this.dir==0)
    {
      for (int i=this.x; i<this.x+this.len; i++)
        this.owner.fields[i][this.y]=3;
    }
    if (this.dir==1)
    {
      for (int i=this.y; i<this.y+this.len; i++)
        this.owner.fields[this.x][i]=3;
    }
  }
}

  public void settings() {  size(1100, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "battleships" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
